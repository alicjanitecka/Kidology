
class ValidationError(Exception):
    pass

class AuthenticationError(Exception):
    pass

class PermissionError(Exception):
    pass

class NotFoundError(Exception):
    pass
